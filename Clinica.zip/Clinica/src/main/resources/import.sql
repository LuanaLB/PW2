insert into Pessoa (tipo, nome, crm) values ( 'M','Pedro', '90.264/SP');
insert into Pessoa (tipo, nome, crm) values ( 'M','Fernanda', '80.355/TO');
insert into Pessoa (tipo, nome, telefone) values ('P', 'Julia', 235689);
insert into Pessoa (tipo, nome, telefone) values ('P', 'Renata',124578);

insert into Consulta (valor, medico_id, paciente_id, dataEHorario, observacao) values (200, 1 , 3, ' 2001-11-01T05:06', 'Raio-X');
insert into Consulta (valor, medico_id, paciente_id, dataEHorario, observacao) values (150, 2 , 4, '2001-11-01T05:06', 'Ultrasson');