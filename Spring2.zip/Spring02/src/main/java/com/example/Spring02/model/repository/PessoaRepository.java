package com.example.Spring02.model.repository;

public class PessoaRepository {
}
